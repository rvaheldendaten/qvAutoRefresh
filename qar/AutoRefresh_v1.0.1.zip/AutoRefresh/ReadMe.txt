﻿// ------------------------------------------------------------------
// "AutoRefresh" QlikView Document Extension
// ~~
// "AutoRefresh" is a QlikView Document Extension which enables you to 
// add the ability to a QlikView application that it will be refreshed 
// automatically every X seconds.
// ------------------------------------------------------------------
// Copyright
// ~~
// Stefan Walther - 11/26/2013
//
// ~~
// DOCUMENTATION:
//      https://github.com/stefanwalther/QlikView-Extension-AutoRefresh/
// ~~
// SOURCE CODE:
//      https://github.com/stefanwalther/QlikView-Extension-AutoRefresh/
// ~~
// LICENSE:
//      MIT License
// ------------------------------------------------------------------

